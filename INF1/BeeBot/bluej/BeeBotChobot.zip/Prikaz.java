public enum Prikaz {
    VLAVO,
    VPRAVO,
    KROK;
}
